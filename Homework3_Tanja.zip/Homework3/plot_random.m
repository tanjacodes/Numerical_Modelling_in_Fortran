load twoD_results_random.dat
contourf(twoD_results_random)


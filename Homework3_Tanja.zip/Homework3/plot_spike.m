load twoD_results_spike.dat
contourf(twoD_results_spike)




